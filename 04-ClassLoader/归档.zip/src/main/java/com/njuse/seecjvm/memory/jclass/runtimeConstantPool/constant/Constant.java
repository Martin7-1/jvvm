package com.njuse.seecjvm.memory.jclass.runtimeConstantPool.constant;

public interface Constant {
}
