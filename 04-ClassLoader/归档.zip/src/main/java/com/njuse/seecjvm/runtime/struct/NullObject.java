package com.njuse.seecjvm.runtime.struct;

public class NullObject extends JObject {
    public NullObject() {
        this.isNull = true;
    }
}
